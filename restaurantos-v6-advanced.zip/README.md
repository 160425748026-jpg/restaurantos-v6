# RestaurantOS V6 Advanced

A zero-build static restaurant operations demo for phone and laptop browsers.

## Features
- Responsive admin dashboard
- Restaurant branding/settings
- Menu CRUD and availability
- Tables and QR links
- Customer menu and cart
- Demo payment and automatic paid-order creation
- Kitchen queue: QUEUED → IN_PROGRESS → READY → SERVED
- Orders and analytics
- Local browser persistence with localStorage
- GitHub Pages compatible; no localhost/server dependency

## Publish from a phone
1. Create a GitHub repository.
2. Upload `index.html`, `.nojekyll`, and this README.
3. Settings → Pages → Deploy from a branch → `main` → `/ (root)`.
4. Open the generated Pages URL.

## Important production note
This is a front-end demo. For real restaurants and real payments, use a secure backend/database, authentication/roles, server-side payment verification/webhooks, HTTPS, backups, rate limiting, and cross-device realtime synchronization.

QR images use an online QR-image service; the QR target itself is the current GitHub Pages URL plus the table query.
